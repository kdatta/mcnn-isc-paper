# dmpa-hossaim2-intel_mcnn_paper

Internal repo to share drafts of MCNN performance optimization paper, in collaboration with Intel.